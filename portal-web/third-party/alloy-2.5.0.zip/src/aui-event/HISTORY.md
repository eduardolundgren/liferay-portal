AUI Event
========

@VERSION@
------

	* #AUI-749 aui-event-input.js IE9 does not support propertychange properly, cannot detect backspaces