# AUI Property Builder

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-property-builder).

## @VERSION@

No registries yet

# [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

* [AUI-1536](https://issues.liferay.com/browse/AUI-1536) FormBuilder - Nested fields not working after refactoring
* [AUI-1303](https://issues.liferay.com/browse/AUI-1303) Make aui-form-builder responsive
* [AUI-1332](https://issues.liferay.com/browse/AUI-1332) Decouple property list panel from the diagram builder